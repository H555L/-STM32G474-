/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "adc.h"
#include "cordic.h"
#include "dma.h"
#include "fmac.h"
#include "tim.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "config.h"

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
uint16_t adc_dma_buffer[ADC_CHANNEL_COUNT];
uint16_t adc_valid_buf[3];

extern uint8_t  pwmRunning;
extern uint8_t sample_ok;
extern uint16_t adc_buffer_copy1[SAMPLE_COUNT];
extern float instMod;
uint8_t Num;

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */
	// 手动开启M4F单精度FPU
	SCB->CPACR |= ((3UL << 10*2)|(3UL << 11*2));
	__DSB();
	__ISB();
  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_ADC1_Init();
  MX_TIM1_Init();
  MX_CORDIC_Init();
  MX_FMAC_Init();
  MX_TIM2_Init();
  MX_TIM6_Init();
  /* USER CODE BEGIN 2 */
	OLED_Init();
	
	HAL_TIM_PWM_Start(&htim1 ,TIM_CHANNEL_1);
	HAL_TIM_PWM_Start(&htim2 ,TIM_CHANNEL_2);
	
	HAL_ADCEx_Calibration_Start(&hadc1, ADC_SINGLE_ENDED);
	while( hadc1.Instance->CR & ADC_CR_ADCAL );
	// 开启DMA
	HAL_ADC_Start_DMA(&hadc1, (uint32_t*)adc_dma_buffer, ADC_CHANNEL_COUNT);
	
	HAL_TIM_Base_Start_IT(&htim1);	//spwm更新中断
	HAL_TIM_Base_Start_IT(&htim2);
	HAL_TIM_Base_Start_IT(&htim6);
	
	Inverter_Init();
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */

  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
	  
	if(Key_Check(KEY_SINGLE))
	{
		// 短按：仅待机切运行，故障模式下无效，防止误触恢复
		if(inverter.mode == MODE_STANDBY)
		{
			inverter.mode = MODE_OFF_GRID;
			Fault_ResetStartTimer();
		}
	}

	if(Key_Check(KEY_LONG))
	{
		// 长按：故障复位，强制切回运行并清除故障
		if(inverter.mode == MODE_FAULT)
		{
			Fault_Clear();
			inverter.mode = MODE_OFF_GRID;
			Fault_ResetStartTimer();
		}
	}
	
	
    if (sample_ok == 0)
        continue;

    // 1、统一采样换算（唯一一次RMS/校准/滤波计算）
    Sample_Update();
	
	Fault_Check();
	
    Inverter_Control();

    // 全部采样依赖计算执行完毕，再解锁缓冲区，杜绝THD波形撕裂
    sample_ok = 0;

    // OLED刷新：仅读取结构体缓存，不操作原始ADC数组
	OLED_ShowString(0,0,"WS:",8);
    OLED_ShowNum(32,0,pwmRunning,2,8);
			
    //OLED_ShowFloatNum(120, 0, THD, 1, 3, OLED_8X16);
	
	OLED_ShowString(0,16,"AC_V_RMS:",6);
	OLED_ShowFloatNum(64, 16, inverter.v_out_rms, 2, 2, 6);
	
	OLED_ShowString(0,28,"AC_I_RMS:",6);
    OLED_ShowFloatNum(64, 28, inverter.i_out_rms, 1, 2, 6);
	
	OLED_ShowString(0,40,"THD:",6);
	
	OLED_ShowString(0,40,"THD:",6);
	OLED_ShowString(68,40,"PWR:",6);
	OLED_ShowFloatNum(90,40,inverter.v_out_rms*inverter.i_out_rms,2,1,6);
	
	
	OLED_ShowString(0,52,"DC_RMS:",6);
	OLED_ShowFloatNum(64, 52, inverter.dc_bus, 2, 2, 6);
	HAL_GPIO_WritePin(GPIOC,GPIO_PIN_0,!pwmRunning);
	
	
    OLED_Update();
	
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1_BOOST);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = RCC_PLLM_DIV2;
  RCC_OscInitStruct.PLL.PLLN = 85;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = RCC_PLLQ_DIV2;
  RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_4) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */
void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef *hadc)
{
    if(hadc->Instance == ADC1)
    {
        memcpy(adc_valid_buf, adc_dma_buffer, sizeof(adc_valid_buf));
    }
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
